﻿using Final_proyecto.Data;
using Final_proyecto.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Security.Claims;
using Microsoft.EntityFrameworkCore;


namespace Final_proyecto.Controllers
{
    [Authorize]
    public class CarritoController : Controller
    {
        private readonly ApplicationDbContext _context;

        public CarritoController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Historial()
        {
            var userEmail = User.Identity.Name;

            var cliente = _context.Clientes.FirstOrDefault(c => c.Email == userEmail);

            if (cliente == null)
                return Unauthorized();

            var historial = _context.HistorialCompra
                .Where(h => h.ClienteId == cliente.UserId) // ← ahora ambos son string
                .OrderByDescending(h => h.FechaCompra)
                .Select(h => new
                {
                    h.FechaCompra,
                    h.Coche.Marca,
                    h.Coche.Modelo,
                    h.Coche.Color,
                    h.Coche.Año
                })
                .ToList();

            return View(historial);
        }


        [Authorize(Roles = "Comprador")]
        [HttpPost]
        public IActionResult AgregarAlCarrito(int cocheId)
        {
            var clienteEmail = User.Identity.Name;
            var cliente = _context.Clientes.FirstOrDefault(c => c.Email == clienteEmail);

            if (cliente == null)
                return Unauthorized();

            var coche = _context.Coches.FirstOrDefault(c => c.Id == cocheId);

            if (coche == null)
            {
                TempData["Error"] = "El coche seleccionado no existe.";
                return RedirectToAction("Index", "Coches");
            }

            if (coche.Stock <= 0)
            {
                TempData["Error"] = "Este coche no tiene stock disponible.";
                return RedirectToAction("Index", "Coches");
            }

            var yaEnCarrito = _context.Carrito.Any(c => c.ClienteId == cliente.Id && c.CocheId == cocheId);
            if (yaEnCarrito)
            {
                TempData["Error"] = "Este coche ya está en tu carrito.";
                return RedirectToAction("Index", "Coches");
            }

            var itemCarrito = new Carrito
            {
                ClienteId = cliente.Id,
                CocheId = cocheId,
                FechaAgregado = DateTime.Now
            };

            _context.Carrito.Add(itemCarrito);
            _context.SaveChanges();

            TempData["Success"] = "Coche agregado al carrito.";
            return RedirectToAction("Index", "Coches");
        }



    }
}