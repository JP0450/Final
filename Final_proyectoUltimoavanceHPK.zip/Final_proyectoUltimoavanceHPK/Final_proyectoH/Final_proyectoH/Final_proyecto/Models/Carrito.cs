﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Final_proyecto.Models
{
    public class Carrito
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int ClienteId { get; set; }
        public Clientes Cliente { get; set; }

        [Required]
        public int CocheId { get; set; }
        public Coches Coche { get; set; }

        public DateTime FechaAgregado { get; set; } = DateTime.Now;
    }
}