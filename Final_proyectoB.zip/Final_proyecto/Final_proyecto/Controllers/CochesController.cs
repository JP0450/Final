﻿using Final_proyecto.Data;
using Final_proyecto.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace Final_proyecto.Controllers
{
    public class CochesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public CochesController(ApplicationDbContext context)
        {
            _context = context;
        }

        // Acción para mostrar todos los coches
        public async Task<IActionResult> Index()
        {
            var coches = await _context.Coches.ToListAsync();
            return View(coches);
        }
    }
}

