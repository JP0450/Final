﻿using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using System.Text;
using Final_proyecto.Data;
using Microsoft.EntityFrameworkCore;
using Final_proyecto.Models;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;

namespace Final_proyecto.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class LoginController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public LoginController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] Final_proyecto.Models.LoginRequest request)
        {
            var usuario = await _context.Clientes
                .FirstOrDefaultAsync(c => c.Email == request.email);

            if (usuario == null || usuario.Contraseña != request.contrasena)
                return Unauthorized("Credenciales incorrectas");

            var token = GenerarToken(usuario.Email, usuario.Rol);

            return Ok(new { token });
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] Final_proyecto.Models.RegisterRequest request)
        {
            if (string.IsNullOrWhiteSpace(request.Email) || string.IsNullOrWhiteSpace(request.Contraseña))
                return BadRequest("Email y contraseña son requeridos");

            if (await _context.Clientes.AnyAsync(c => c.Email == request.Email))
                return BadRequest("El correo ya está registrado");

            var nuevoCliente = new Clientes
            {
                Email = request.Email,
                Contraseña = request.Contraseña,
                Rol = "Comprador" // Siempre será comprador
            };

            _context.Clientes.Add(nuevoCliente);
            await _context.SaveChangesAsync();

            return Ok("Cuenta creada con éxito");
        }

        private string GenerarToken(string email, string rol)
        {
            var key = Encoding.ASCII.GetBytes("clave_super_secreta_para_el_token");

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[]
                {
                    new Claim(ClaimTypes.Name, email),
                    new Claim(ClaimTypes.Role, rol)
                }),
                Expires = DateTime.UtcNow.AddHours(1), // El token por sí solo expira en 1h
                SigningCredentials = new SigningCredentials(
                    new SymmetricSecurityKey(key),
                    SecurityAlgorithms.HmacSha256Signature)
            };

            var tokenHandler = new JwtSecurityTokenHandler();
            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }
    }
}



