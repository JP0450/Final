﻿using Microsoft.EntityFrameworkCore;


using Final_proyecto.Models;
using static Final_proyecto.Models.Clientes;
using Npgsql.EntityFrameworkCore.PostgreSQL.Query.ExpressionTranslators.Internal;

namespace Final_proyecto.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        //clientes (verde) nombre del modelo cliente (blanco) nombre de la tabla que se crea
        //dbset objeto que representa una tabla en la base de datos de tipo clientes (el modelo que se hizo)
        public DbSet<Clientes> Clientes { get; set; }
        public DbSet<Coches> Coches { get; set; }
        public DbSet<HistorialCompra> HistorialCompra { get; set; }
        public DbSet<Carrito> Carrito { get; set; }



        // Otros DbSets para modelos  

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Agregar coches de ejemplo si la tabla está vacía
           
        }
    }
}
