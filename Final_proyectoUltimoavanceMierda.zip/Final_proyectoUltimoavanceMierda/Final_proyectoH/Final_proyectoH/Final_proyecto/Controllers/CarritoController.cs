﻿using Final_proyecto.Data;
using Final_proyecto.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Security.Claims;
using Microsoft.EntityFrameworkCore;


namespace Final_proyecto.Controllers
{
    [Authorize]
    public class CarritoController : Controller
    {
        private readonly ApplicationDbContext _context;

        public CarritoController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Historial()
        {
            var userEmail = User.Identity.Name;

            var cliente = _context.Clientes.FirstOrDefault(c => c.Email == userEmail);

            if (cliente == null)
                return Unauthorized();

            var historial = _context.HistorialCompra
                .Where(h => h.ClienteId == cliente.UserId) // ← ahora ambos son string
                .OrderByDescending(h => h.FechaCompra)
                .Select(h => new
                {
                    h.FechaCompra,
                    h.Coche.Marca,
                    h.Coche.Modelo,
                    h.Coche.Color,
                    h.Coche.Año
                })
                .ToList();

            return View(historial);
        }



        [Authorize]
        [HttpPost]
        public IActionResult Comprar()
        {
            var clienteEmail = User.Identity.Name;
            var cliente = _context.Clientes.FirstOrDefault(c => c.Email == clienteEmail);

            if (cliente == null)
                return Unauthorized();

            var itemsCarrito = _context.Carrito
                .Include(c => c.Coche)
                .Where(c => c.ClienteId == cliente.Id)
                .ToList();

            if (!itemsCarrito.Any())
            {
                TempData["Error"] = "El carrito está vacío.";
                return RedirectToAction("Index");
            }

            foreach (var item in itemsCarrito)
            {
                if (item.Coche.Stock < 1)
                {
                    TempData["Error"] = $"No hay suficiente stock para el coche: {item.Coche.Marca} {item.Coche.Modelo}.";
                    return RedirectToAction("Index");
                }
            }

            foreach (var item in itemsCarrito)
            {
                // Restar stock
                item.Coche.Stock -= 1;

                // Registrar historial
                var historial = new HistorialCompra
                {
                    ClienteId = cliente.Id,
                    CocheId = item.CocheId,
                    Cantidad = 1,
                    FechaCompra = DateTime.Now
                };
                _context.HistorialCompra.Add(historial);
            }

            // Limpiar carrito
            _context.Carrito.RemoveRange(itemsCarrito);
            _context.SaveChanges();

            TempData["Success"] = "Compra realizada exitosamente.";
            return RedirectToAction("Index", "Coches");
        }

    }
}
