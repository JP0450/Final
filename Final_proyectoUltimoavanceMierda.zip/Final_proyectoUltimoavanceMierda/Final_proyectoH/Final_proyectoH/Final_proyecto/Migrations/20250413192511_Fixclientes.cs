﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Final_proyecto.Migrations
{
    /// <inheritdoc />
    public partial class Fixclientes : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Nombre",
                table: "Clientes",
                newName: "Contraseña");

            migrationBuilder.AddColumn<int>(
                name: "Npuertas",
                table: "Coches",
                type: "integer",
                nullable: false,
                defaultValue: 0);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Npuertas",
                table: "Coches");

            migrationBuilder.RenameColumn(
                name: "Contraseña",
                table: "Clientes",
                newName: "Nombre");
        }
    }
}
