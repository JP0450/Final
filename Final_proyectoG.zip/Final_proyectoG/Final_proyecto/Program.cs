using Final_proyecto.Data;
using Final_proyecto.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();
//para conectar a la base de datos
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseNpgsql(builder.Configuration.GetConnectionString("DefaultConnection")));

/////////////////
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});

/////////////////
///
var app = builder.Build();
/////////////
app.UseCors("AllowAll"); // Antes de app.UseAuthorization();
////////////////////////
// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();



app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");


////////////////////////////////////////////////////////////// datos para la base de datos (prueba)

using (var scope = app.Services.CreateScope())
{
    var context = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();

    // Solo si no hay datos
    if (!context.Coches.Any())
    {
        context.Coches.AddRange(
            new Coches
            {
                Marca = "Toyota",
                Modelo = "Corolla",
                A�o = 2022,
                Color = "Blanco",
                Npuertas = 4,
                Precio = 23000.50m,
                ImagenUrl = "https://example.com/honda-civic.jpg"
            },
            new Coches
            {
                Marca = "Honda",
                Modelo = "Civic",
                A�o = 2021,
                Color = "Gris",
                Npuertas = 4,
                Precio = 21000.00m,
                ImagenUrl = "https://example.com/honda-civic.jpg"
            },
            new Coches
            {
                Marca = "Chevrolet",
                Modelo = "Aveo",
                A�o = 2020,
                Color = "Rojo",
                Npuertas = 4,
                Precio = 18000.00m,
                ImagenUrl = "https://example.com/chevrolet-aveo.jpg"
            }
        );

        context.SaveChanges(); // Guardar en la BD
    }
}


app.Run();




