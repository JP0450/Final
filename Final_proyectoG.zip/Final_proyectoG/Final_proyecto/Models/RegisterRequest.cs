﻿using System.ComponentModel.DataAnnotations;

namespace Final_proyecto.Models
{
    public class RegisterRequest
    {
        [Required, EmailAddress]
        public string Email { get; set; }

        [Required, MinLength(10)]
        public string Contraseña { get; set; }
    }
}
