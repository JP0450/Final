﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Final_proyecto.Migrations
{
    /// <inheritdoc />
    public partial class historialcompraycarritoFix : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Carritos_Clientes_ClienteId",
                table: "Carritos");

            migrationBuilder.DropForeignKey(
                name: "FK_Carritos_Coches_CochesId",
                table: "Carritos");

            migrationBuilder.DropForeignKey(
                name: "FK_HistorialCompras_Clientes_ClienteId",
                table: "HistorialCompras");

            migrationBuilder.DropForeignKey(
                name: "FK_HistorialCompras_Coches_CochesId",
                table: "HistorialCompras");

            migrationBuilder.DropPrimaryKey(
                name: "PK_HistorialCompras",
                table: "HistorialCompras");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Carritos",
                table: "Carritos");

            migrationBuilder.RenameTable(
                name: "HistorialCompras",
                newName: "HistorialCompra");

            migrationBuilder.RenameTable(
                name: "Carritos",
                newName: "Carrito");

            migrationBuilder.RenameIndex(
                name: "IX_HistorialCompras_CochesId",
                table: "HistorialCompra",
                newName: "IX_HistorialCompra_CochesId");

            migrationBuilder.RenameIndex(
                name: "IX_HistorialCompras_ClienteId",
                table: "HistorialCompra",
                newName: "IX_HistorialCompra_ClienteId");

            migrationBuilder.RenameIndex(
                name: "IX_Carritos_CochesId",
                table: "Carrito",
                newName: "IX_Carrito_CochesId");

            migrationBuilder.RenameIndex(
                name: "IX_Carritos_ClienteId",
                table: "Carrito",
                newName: "IX_Carrito_ClienteId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_HistorialCompra",
                table: "HistorialCompra",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Carrito",
                table: "Carrito",
                column: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Carrito_Clientes_ClienteId",
                table: "Carrito",
                column: "ClienteId",
                principalTable: "Clientes",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Carrito_Coches_CochesId",
                table: "Carrito",
                column: "CochesId",
                principalTable: "Coches",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_HistorialCompra_Clientes_ClienteId",
                table: "HistorialCompra",
                column: "ClienteId",
                principalTable: "Clientes",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_HistorialCompra_Coches_CochesId",
                table: "HistorialCompra",
                column: "CochesId",
                principalTable: "Coches",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Carrito_Clientes_ClienteId",
                table: "Carrito");

            migrationBuilder.DropForeignKey(
                name: "FK_Carrito_Coches_CochesId",
                table: "Carrito");

            migrationBuilder.DropForeignKey(
                name: "FK_HistorialCompra_Clientes_ClienteId",
                table: "HistorialCompra");

            migrationBuilder.DropForeignKey(
                name: "FK_HistorialCompra_Coches_CochesId",
                table: "HistorialCompra");

            migrationBuilder.DropPrimaryKey(
                name: "PK_HistorialCompra",
                table: "HistorialCompra");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Carrito",
                table: "Carrito");

            migrationBuilder.RenameTable(
                name: "HistorialCompra",
                newName: "HistorialCompras");

            migrationBuilder.RenameTable(
                name: "Carrito",
                newName: "Carritos");

            migrationBuilder.RenameIndex(
                name: "IX_HistorialCompra_CochesId",
                table: "HistorialCompras",
                newName: "IX_HistorialCompras_CochesId");

            migrationBuilder.RenameIndex(
                name: "IX_HistorialCompra_ClienteId",
                table: "HistorialCompras",
                newName: "IX_HistorialCompras_ClienteId");

            migrationBuilder.RenameIndex(
                name: "IX_Carrito_CochesId",
                table: "Carritos",
                newName: "IX_Carritos_CochesId");

            migrationBuilder.RenameIndex(
                name: "IX_Carrito_ClienteId",
                table: "Carritos",
                newName: "IX_Carritos_ClienteId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_HistorialCompras",
                table: "HistorialCompras",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Carritos",
                table: "Carritos",
                column: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Carritos_Clientes_ClienteId",
                table: "Carritos",
                column: "ClienteId",
                principalTable: "Clientes",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Carritos_Coches_CochesId",
                table: "Carritos",
                column: "CochesId",
                principalTable: "Coches",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_HistorialCompras_Clientes_ClienteId",
                table: "HistorialCompras",
                column: "ClienteId",
                principalTable: "Clientes",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_HistorialCompras_Coches_CochesId",
                table: "HistorialCompras",
                column: "CochesId",
                principalTable: "Coches",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
