﻿using Final_proyecto.Data;
using Final_proyecto.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace Final_proyecto.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class HistorialController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public HistorialController(ApplicationDbContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Obtiene el historial de compras del usuario logueado.
        /// Si el usuario tiene rol "Administrador", ve todos los historiales.
        /// Si es "Comprador", solo ve su propio historial.
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> Historial()
        {
            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
            var rol = User.FindFirst(ClaimTypes.Role)?.Value;

            IQueryable<HistorialCompra> query = _context.HistorialCompra.Include(h => h.Coche);

            if (rol == "Comprador")
            {
                query = query.Where(h => h.ClienteId == userId);
            }

            var historial = await query.ToListAsync();
            return Ok(historial);
        }

        /// <summary>
        /// Confirma la compra de todos los elementos del carrito actual del usuario logueado.
        /// Elimina el carrito después de registrar las compras.
        /// </summary>
        [HttpPost("comprar")]
        public async Task<IActionResult> ConfirmarCompra()
        {
            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);

            var carritoItems = await _context.Carrito
                .Where(c => c.ClienteId == userId)
                .ToListAsync();

            if (!carritoItems.Any())
                return BadRequest("El carrito está vacío.");

            foreach (var item in carritoItems)
            {
                var coche = await _context.Coches.FindAsync(item.CocheId);
                if (coche == null || coche.Stock < item.Cantidad)
                    return BadRequest($"Stock insuficiente para el coche con ID {item.CocheId}");

                // Registrar en historial
                var historial = new HistorialCompra
                {
                    ClienteId = userId,
                    CocheId = item.CocheId,
                    Cantidad = item.Cantidad,
                    FechaCompra = DateTime.Now
                };
                _context.HistorialCompra.Add(historial);

                // Actualizar stock
                coche.Stock -= item.Cantidad;
                _context.Coches.Update(coche);
            }

            // Limpiar carrito
            _context.Carrito.RemoveRange(carritoItems);

            await _context.SaveChangesAsync();
            return Ok("Compra realizada con éxito y carrito vaciado.");
        }
    }
}
