﻿using Final_proyecto.Data;
using Final_proyecto.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;

namespace Final_proyecto.Controllers
{
    [Authorize]
    public class PerfilController : Controller
    {
        private readonly ApplicationDbContext _context;

        public PerfilController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);

            var carrito = await _context.Carrito
                .Include(c => c.Coches)
                .Where(c => c.ClienteId == userId)
                .ToListAsync();

            return View(carrito);
        }

        public async Task<IActionResult> Historial()
        {
            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);

            var historial = await _context.HistorialCompra
                .Include(h => h.Coche)
                .Where(h => h.ClienteId == userId)
                .ToListAsync();

            return View(historial);
        }



    }
}
