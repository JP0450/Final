﻿using Final_proyecto.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Final_proyecto.Data;
using Microsoft.AspNetCore.Identity.Data;

namespace Final_proyecto.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class LoginController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        private readonly CodigoVerificacionService _codigoService;

        public LoginController(ApplicationDbContext context, CodigoVerificacionService codigoService)
        {
            _context = context;
            _codigoService = codigoService;
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginRequest request)
        {
            var cliente = await _context.Clientes.FirstOrDefaultAsync(c => c.Email == request.Email && c.Contraseña == request.Contraseña);
            if (cliente == null)
                return Unauthorized("Credenciales incorrectas.");

            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, cliente.Email),
                new Claim(ClaimTypes.Role, cliente.Rol)
            };

            var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
            var principal = new ClaimsPrincipal(identity);

            await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal, new AuthenticationProperties
            {
                IsPersistent = true,
                ExpiresUtc = DateTime.UtcNow.AddHours(2)
            });

            return Ok("Inicio de sesión exitoso.");
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegistroRequest request)
        {
            if (!_codigoService.VerificarCodigo(request.Email, request.CodigoVerificacion))
                return BadRequest("Código de verificación incorrecto o expirado.");

            var existente = await _context.Clientes.AnyAsync(c => c.Email == request.Email);
            if (existente)
                return BadRequest("El correo ya está registrado.");

            var nuevoCliente = new Clientes
            {
                Email = request.Email,
                Contraseña = request.Contraseña,
                Rol = "Comprador"
            };

            _context.Clientes.Add(nuevoCliente);
            await _context.SaveChangesAsync();

            return Ok("Cuenta registrada correctamente.");
        }

        [HttpPost("enviar-codigo")]
        public async Task<IActionResult> EnviarCodigo([FromBody] EmailRequest request)
        {
            var enviado = await _codigoService.EnviarCodigoAsync(request.Email);
            if (!enviado)
                return BadRequest("Error al enviar el código.");
            return Ok("Código enviado correctamente.");
        }

        [HttpPost("reset-password")]
        public async Task<IActionResult> ResetPassword([FromBody] ResetPasswordRequest request)
        {
            if (!_codigoService.VerificarCodigo(request.Email, request.CodigoVerificacion))
                return BadRequest("Código de verificación incorrecto o expirado.");

            var cliente = await _context.Clientes.FirstOrDefaultAsync(c => c.Email == request.Email);
            if (cliente == null)
                return NotFound("Cuenta no encontrada.");

            cliente.Contraseña = request.NewPassword;
            await _context.SaveChangesAsync();

            return Ok("Contraseña restablecida correctamente.");
        }

        [HttpPost("logout")]
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return Ok("Sesión cerrada.");
        }

        // ENVIAR CÓDIGO DE VERIFICACIÓN
        [HttpPost("enviar-codigo")]
        public async Task<IActionResult> EnviarCodigoVerificacion([FromBody] EmailRequest request)
        {
            var email = request.Email;

            if (string.IsNullOrWhiteSpace(email))
                return BadRequest("El email es requerido");

            var codigo = new Random().Next(100000, 999999).ToString();

            codigosVerificacion[email] = codigo;

            string asunto = "Código de verificación";
            string cuerpo = $"<h2>Tu código es: {codigo}</h2>";

            await _emailService.SendEmailAsync(email, asunto, cuerpo);

            return Ok("Código enviado");
        }

        // CERRAR SESIÓN
        [HttpPost("logout")]
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return Ok("Sesión cerrada");
        }
    }
}

