﻿using Microsoft.AspNetCore.Mvc;

namespace Final_proyecto.Controllers
{
    public class AdminController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
