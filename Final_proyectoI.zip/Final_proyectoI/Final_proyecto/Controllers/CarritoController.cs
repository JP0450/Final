﻿using Final_proyecto.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace Final_proyecto.Controllers
{
    [Authorize(Roles = "Comprador")]
    public class CarritoController : Controller
    {
        private readonly ApplicationDbContext _context;

        public CarritoController(ApplicationDbContext context)
        {
            _context = context;
        }


        public async Task<IActionResult> Index()
        {
            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);

            var carrito = await _context.Carrito
                .Include(c => c.Coches)
                .Where(c => c.ClienteId == userId)
                .ToListAsync();

            return View(carrito);
        }

        [HttpPost]
        public async Task<IActionResult> Eliminar(int id)
        {
            var item = await _context.Carrito.FindAsync(id);
            if (item == null)
            {
                TempData["Error"] = "Elemento no encontrado.";
                return RedirectToAction("Index");
            }

            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
            if (item.ClienteId != userId)
            {
                TempData["Error"] = "No autorizado.";
                return RedirectToAction("Index");
            }

            _context.Carrito.Remove(item);
            await _context.SaveChangesAsync();

            TempData["Success"] = "Coche eliminado del carrito.";
            return RedirectToAction("Index");
        }

        [HttpPost]
        public async Task<IActionResult> FinalizarCompra()
        {
            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);

            var carrito = await _context.Carrito
                .Include(c => c.Coches)
                .Where(c => c.ClienteId == userId)
                .ToListAsync();

            if (!carrito.Any())
            {
                TempData["Error"] = "El carrito está vacío.";
                return RedirectToAction("Index");
            }

            foreach (var item in carrito)
            {
                if (item.Cantidad > item.Coches.Stock)
                {
                    TempData["Error"] = $"Stock insuficiente para {item.Coches.Marca} {item.Coches.Modelo}.";
                    return RedirectToAction("Index");
                }
            }

            foreach (var item in carrito)
            {
                _context.HistorialCompra.Add(new Models.HistorialCompra
                {
                    ClienteId = userId,
                    CocheId = item.CocheId,
                    Cantidad = item.Cantidad,
                    FechaCompra = DateTime.Now
                });

                item.Coches.Stock -= item.Cantidad;
            }

            _context.Carrito.RemoveRange(carrito);
            await _context.SaveChangesAsync();

            TempData["Success"] = "Compra realizada con éxito.";
            return RedirectToAction("Index");
        }
    }
}

