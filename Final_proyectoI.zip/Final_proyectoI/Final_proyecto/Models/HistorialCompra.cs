﻿namespace Final_proyecto.Models
{
    public class HistorialCompra
    {
        public int Id { get; set; }
        public int ClienteId { get; set; }
        public int CocheId { get; set; }
        public int Cantidad { get; set; }
        public DateTime FechaCompra { get; set; }

        public Clientes Cliente { get; set; }
        public Coches Coche { get; set; }
    }
}
