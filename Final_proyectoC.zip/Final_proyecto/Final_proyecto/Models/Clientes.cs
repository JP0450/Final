﻿namespace Final_proyecto.Models
{
    public class Clientes
    {
        public int Id { get; set; }
        public string Email { get; set; }
        public string Contraseña { get; set; }
        // Otras propiedades  
    }
}
