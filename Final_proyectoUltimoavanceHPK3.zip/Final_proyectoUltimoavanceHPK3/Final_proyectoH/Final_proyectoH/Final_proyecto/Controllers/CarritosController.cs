﻿using Final_proyecto.Data;
using Final_proyecto.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace Final_proyecto.Controllers.Api
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class CarritoApiController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public CarritoApiController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpPost("Agregar/{cocheId}")]
        [Authorize(Roles = "Comprador")]
        public IActionResult AgregarAlCarrito(int cocheId)
        {
            var clienteEmail = User.Identity.Name;
            var cliente = _context.Clientes.FirstOrDefault(c => c.Email == clienteEmail);

            if (cliente == null)
                return Unauthorized();

            var coche = _context.Coches.FirstOrDefault(c => c.Id == cocheId);
            if (coche == null || coche.Stock <= 0)
                return BadRequest("Coche no válido o sin stock");

            var yaEnCarrito = _context.Carrito.Any(c => c.ClienteId == cliente.Id && c.CocheId == cocheId);
            if (yaEnCarrito)
                return Conflict("Ya está en el carrito");

            var itemCarrito = new Carrito
            {
                ClienteId = cliente.Id,
                CocheId = cocheId,
                FechaAgregado = DateTime.Now
            };

            _context.Carrito.Add(itemCarrito);
            _context.SaveChanges();

            return Ok(new { mensaje = "Coche agregado al carrito." });
        }

        [HttpPost("Comprar/{cocheId}")]
        [Authorize(Roles = "Comprador")]
        public IActionResult Comprar(int cocheId)
        {
            var clienteEmail = User.Identity.Name;
            var cliente = _context.Clientes.FirstOrDefault(c => c.Email == clienteEmail);

            if (cliente == null)
                return Unauthorized();

            var coche = _context.Coches.FirstOrDefault(c => c.Id == cocheId);
            if (coche == null || coche.Stock <= 0)
                return BadRequest("Coche no disponible");

            coche.Stock--;

            var historial = new HistorialCompra
            {
                ClienteId = cliente.Id,
                CocheId = coche.Id,
                Cantidad = 1,
                FechaCompra = DateTime.Now
            };

            _context.HistorialCompra.Add(historial);
            _context.SaveChanges();

            return Ok(new { mensaje = "Compra realizada con éxito." });
        }
    }
}
