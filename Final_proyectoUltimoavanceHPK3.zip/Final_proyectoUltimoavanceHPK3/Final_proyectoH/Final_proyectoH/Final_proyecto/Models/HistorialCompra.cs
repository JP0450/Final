﻿using Final_proyecto.Models;
using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations.Schema;

namespace Final_proyecto.Models
{

    [Table("HistorialCompras")]
    public class HistorialCompra
    {
        public int Id { get; set; }

        public int ClienteId { get; set; }     // Cambiar a int
        public Clientes Cliente { get; set; }  // Relación con tu modelo Clientes


        public int CocheId { get; set; }

        public int Cantidad { get; set; } // Esta propiedad es la que falta

        public DateTime FechaCompra { get; set; }

        // Relaciones de navegación (opcional)

        public Coches Coche { get; set; }
    }
}