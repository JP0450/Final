﻿using System.ComponentModel.DataAnnotations;

namespace Final_proyecto.Models
{
    public class Clientes
    {
        [Key]
        public int Id { get; set; }

        [Required, EmailAddress]
        public string Email { get; set; }

        [Required, MinLength(10)]
        public string Contraseña { get; set; }

        [Required]
        public string Rol { get; set; }

        public int UserId { get; set; }
    }

}
