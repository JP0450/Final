﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Final_proyecto.Models
{
    public class CarritoItem
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public int ClienteId { get; set; }

        [ForeignKey("ClienteId")]
        public Clientes Cliente { get; set; }

        [Required]
        public int CocheId { get; set; }

        [ForeignKey("CocheId")]
        public Coches Coche { get; set; }

        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "Cantidad debe ser al menos 1.")]
        public int Cantidad { get; set; }
    }
}